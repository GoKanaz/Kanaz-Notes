# Kanaz Notes 📝

Smart note-taking app with AI integration. Username: **GoKanaz**

## Features
- Create, edit, delete notes
- AI-powered note enhancement
- Categories and tags
- Backup & Restore

## Quick Start
```bash
git clone https://github.com/gokanaz/kanaz-notes.git
cd kanaz-notes
./gradlew assembleDebug